# Databricks notebook source
import requests
import pandas as pd

# COMMAND ----------

model_uri = "https://dbc-93aaa555-94f1.cloud.databricks.com/serving-endpoints/ff_mw/invocations"

# COMMAND ----------

token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

# COMMAND ----------

headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

# COMMAND ----------

df = spark.table('ispl_databricks.model_logs.mw_sample')

# COMMAND ----------

df = df.toPandas()

# COMMAND ----------

df = df.drop_duplicates(['loan_id'])

# COMMAND ----------

df.dtypes

# COMMAND ----------

payload = {
  "dataframe_records": [
    df.iloc[36].to_dict(),

  ]
}


# COMMAND ----------

response = requests.post(model_uri, headers=headers, json=payload)

# COMMAND ----------

response.json()