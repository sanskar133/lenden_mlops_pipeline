# Databricks notebook source
!pip install lightgbm

# COMMAND ----------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import os
import json
import pandas as pd
import pickle
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import joblib
from datetime import datetime, date
import mlflow
import mlflow.lightgbm
from sklearn.metrics import classification_report,roc_auc_score,f1_score
from mlflow.models.signature import infer_signature
from sklearn.preprocessing import LabelEncoder
import json
import requests
import matplotlib.pyplot as plt
import seaborn as sns
from mlflow.tracking import MlflowClient
from sklearn.metrics import accuracy_score


# COMMAND ----------

model_name_500 = 'ispl_databricks.model_logs.ffmw_lgbm_all_columns_endpoint'
model_name_50 = 'ispl_databricks.model_logs.final_mw_model'

# COMMAND ----------

client =MlflowClient()

# COMMAND ----------

version500 = client.search_model_versions(f"name='{model_name_500}'")
version50 = client.search_model_versions(f"name='{model_name_50}'")

# COMMAND ----------

version50

# COMMAND ----------

latest_version500 = str(
    sorted(
        [int(versions.version) for versions in version500],
        reverse=True
    )[0]
)
latest_version50 = str(
    sorted(
        [int(versions.version) for versions in version50],
        reverse=True
    )[0]
)

# COMMAND ----------

latest_version50

# COMMAND ----------

model_uri_500 = f"models:/{model_name_500}/{latest_version500}"
model_uri_50 = f"models:/{model_name_50}/{latest_version50}"

# COMMAND ----------

mv500 = client.get_model_version(name=model_name_500, version=latest_version500)
mv50 = client.get_model_version(name=model_name_50, version=latest_version50)

# COMMAND ----------

mv500run_id = mv500.run_id
mv50run_id = mv50.run_id

# COMMAND ----------

info500 = client.get_run(mv500run_id)
info50 = client.get_run(mv50run_id)

# COMMAND ----------

accuracy500 = info500.data.metrics.get('test_accuracy')

# COMMAND ----------

accuracy50 = info50.data.metrics.get('test_accuracy')

# COMMAND ----------

print(accuracy500)
print(accuracy50)