# Databricks notebook source
!pip install lightgbm

# COMMAND ----------

pip install hyperopt

# COMMAND ----------

# MAGIC %pip install databricks-feature_engineering

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import os
import json
import pandas as pd
import pickle
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import joblib
from datetime import datetime, date
import mlflow
import mlflow.lightgbm
from sklearn.metrics import classification_report,roc_auc_score,f1_score
from mlflow.models.signature import infer_signature
from hyperopt import fmin, tpe, hp, Trials, STATUS_OK
from hyperopt.pyll.base import scope
from databricks.feature_engineering import FeatureEngineeringClient
from databricks.feature_engineering import FeatureEngineeringClient, FeatureLookup
from sklearn.preprocessing import LabelEncoder
import json
import requests
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.metrics import accuracy_score
from pyspark.sql.functions import col


# COMMAND ----------

base_df2 = spark.table("ispl_databricks.model_logs.base_df_500features_updated")

# COMMAND ----------

spark_label =  base_df2.select(col('loan_id'),col('target_30_dpd'))


# COMMAND ----------

fe = FeatureEngineeringClient()

# COMMAND ----------

training_set = fe.create_training_set(
    df=spark_label,
    feature_lookups=[
        FeatureLookup(
            table_name="ispl_databricks.model_logs.mw_final_feature_store",
            lookup_key="loan_id"
        )
    ],
    label="target_30_dpd"
)


# COMMAND ----------

train_pd = training_set.load_df().toPandas()
train_x  = train_pd.drop(['loan_id','target_30_dpd'], axis=1)
train_y = train_pd['target_30_dpd']

# COMMAND ----------

X_train, X_test, y_train, y_test = train_test_split(train_x, train_y, test_size=0.2, random_state=42)

# COMMAND ----------

data_version = 2

# COMMAND ----------

from sklearn.metrics import accuracy_score

# COMMAND ----------

mlflow.set_experiment("/Workspace/Shared/ff_mw/ff_mw/MW_LightGBM_Top50_Training")
if mlflow.active_run():
    mlflow.end_run()

# Train or load LGBMClassifier
with mlflow.start_run(run_name=f"LGBM_{data_version}") as run:

        # -----------------------------
        # Hyperparameter tuning section
        # -----------------------------
    search_space = {
            'num_leaves': scope.int(hp.quniform('num_leaves', 20, 150, 1)),
            'max_depth': scope.int(hp.quniform('max_depth', 3, 15, 1)),
            'learning_rate': hp.uniform('learning_rate', 0.01, 0.3),
            'n_estimators': scope.int(hp.quniform('n_estimators', 100, 800, 50)),
            'min_child_samples': scope.int(hp.quniform('min_child_samples', 10, 100, 5)),
            'subsample': hp.uniform('subsample', 0.6, 1.0),
            'colsample_bytree': hp.uniform('colsample_bytree', 0.6, 1.0)
        }

    def objective(params):
        with mlflow.start_run(nested=True):
            model = lgb.LGBMClassifier(
                random_state=42,
                class_weight='balanced',
                **params
            )
            model.fit(
                X_train, y_train,
                eval_set=[(X_test, y_test)],
                eval_metric="binary_logloss"
            )
            y_pred = model.predict(X_test)
            acc = accuracy_score(y_test,y_pred)
            mlflow.log_metric('accuracy', acc)
            mlflow.log_params(params)
            val_pred_proba = model.predict_proba(X_test)[:, 1]
            val_logloss = -((y_test * np.log(val_pred_proba) + (1 - y_test) * np.log(1 - val_pred_proba)).mean())
            return {'loss': val_logloss, 'status': STATUS_OK}

    trials = Trials()
    best_params = fmin(
            fn=objective,
            space=search_space,
            algo=tpe.suggest,
            max_evals=30,
            trials=trials,
            rstate=np.random.default_rng(42)
        )

        # Convert integer-like floats back to ints
    best_params = {
            k: int(v) if isinstance(v, float) and v.is_integer() else v
            for k, v in best_params.items()
        }

    mlflow.log_params(best_params)
    mlflow.log_param("class_weight", "balanced")
    mlflow.log_param("random_state", 42)

        # -----------------------------
        # Train final model with best params
        # -----------------------------
    model = lgb.LGBMClassifier(
            random_state=42,
            class_weight='balanced',
            **best_params
        )

    model = model.fit(
            X_train,
            y_train,
            eval_set=[(X_train, y_train), (X_test, y_test)],
            eval_names=["train", "valid"],
            eval_metric=["binary_logloss"]
        )
    acc = accuracy_score(y_test, model.predict(X_test))
    mlflow.log_metric("test_accuracy", acc)
    
    

        # Infer model signature from training data and predictions
    

        # Save the trained model locally
    joblib.dump(model,'/Workspace/Shared/ff_mw/ff_mw/model_artifacts/mwtop50_new.pkl')
        

# COMMAND ----------

trained_feature_names = model.feature_name_

# COMMAND ----------

len(trained_feature_names)

# COMMAND ----------

features_json =  {'features' : trained_feature_names,'accuracy':acc}

# COMMAND ----------

joblib.dump(model,'/Workspace/Shared/ff_mw/ff_mw/model_artifacts/mwtop50.pkl')

# COMMAND ----------

with open('/Workspace/Shared/ff_mw/ff_mw/model_artifacts/features.json','w') as f:
    json.dump(features_json, f, ensure_ascii=False, indent=4)

# COMMAND ----------

input_x = train_x[trained_feature_names].iloc[[0]]

# COMMAND ----------

model = joblib.load('/Workspace/Shared/ff_mw/ff_mw/model_artifacts/mwtop50_new.pkl')

# COMMAND ----------

output = model.predict_proba(input_x)


# COMMAND ----------

print(output)

# COMMAND ----------

signature = infer_signature(input_x, output)

# COMMAND ----------

class mlwrapper(mlflow.pyfunc.PythonModel):
    def load_context(self,context):
        self.model = joblib.load(context.artifacts['model_artifacts']+'/mwtop50_new.pkl')
        with open(context.artifacts['model_artifacts']+'/features.json', 'r') as file:
            data = json.load(file)
        self.fc = data['features']
        print(self.fc)
        
    def predict(self,context,model_input):
        df = model_input[self.fc]
        return self.model.predict_proba(df)

# COMMAND ----------

with mlflow.start_run():
    mlflow.log_metric("test_accuracy", acc)


    mlflow.pyfunc.log_model(
        artifact_path="model",
        python_model=mlwrapper(),
        artifacts={"model_artifacts": "/Workspace/Shared/ff_mw/ff_mw/model_artifacts"},
        registered_model_name="ispl_databricks.model_logs.final_mw_model",
        signature=signature
    )

# COMMAND ----------


from mlflow.tracking import MlflowClient
client = MlflowClient()
versions = client.search_model_versions("name = 'ispl_databricks.model_logs.final_mw_model'")

latest_version = sorted(versions, key=lambda v: int(v.version))[-1].version

# COMMAND ----------


model_uri = f'models:/ispl_databricks.model_logs.final_mw_model/{latest_version}'

# COMMAND ----------

model = mlflow.pyfunc.load_model(model_uri)

# COMMAND ----------

model.predict(train_x[trained_feature_names].iloc[[3]])