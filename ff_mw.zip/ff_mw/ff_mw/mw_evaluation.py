# Databricks notebook source
# MAGIC %pip install databricks-feature_engineering

# COMMAND ----------

!pip install lightgbm

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

import pandas as pd
import lightgbm as lgb
import pickle
import joblib
import mlflow
import mlflow.lightgbm
from databricks.feature_engineering import FeatureEngineeringClient
from databricks.feature_engineering import FeatureLookup
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.metrics import (
    roc_auc_score,
    precision_score,
    recall_score
)
import requests

# COMMAND ----------

spark_df_latest = spark.table('ispl_databricks.model_logs.mw_final_feature_store')

# COMMAND ----------

spark_df_production = spark.table('ispl_databricks.model_logs.mw_final_inference_data')

# COMMAND ----------

dbutils.widgets.text("training_csv", "")

# COMMAND ----------


training_csv = dbutils.widgets.get("training_csv")

# COMMAND ----------

df=pd.read_csv(training_csv)


# COMMAND ----------

df.head()

# COMMAND ----------

df.rename(columns={'required_loan_id':'loan_id'}, inplace=True)


# COMMAND ----------

df_label = spark.createDataFrame(df[['loan_id','target_30_dpd']])

# COMMAND ----------

df_production = spark_df_production.join(df_label, on='loan_id', how='inner')
df_production = df_production.toPandas()

# COMMAND ----------

test_production_data = df_production.drop(['loan_id','target_30_dpd'],axis=1)

# COMMAND ----------

test_production_target = df_production[['loan_id','target_30_dpd']]

# COMMAND ----------


fe = FeatureEngineeringClient()

# COMMAND ----------

training_set = fe.create_training_set(
    df=df_label,
    feature_lookups=[
        FeatureLookup(
            table_name="ispl_databricks.model_logs.mw_final_feature_store",
            lookup_key="loan_id"
        )
    ],
    label="target_30_dpd",
   
)


# COMMAND ----------

train_df_latest = training_set.load_df()

# COMMAND ----------

train_df_latest = train_df_latest.toPandas()


# COMMAND ----------

test_target_latest = train_df_latest[['loan_id','target_30_dpd']]

# COMMAND ----------

test_data_latest = train_df_latest.drop(['loan_id','target_30_dpd'], axis=1)

# COMMAND ----------

from mlflow.tracking import MlflowClient

# COMMAND ----------

client = MlflowClient()

# COMMAND ----------

model_name = 'ispl_databricks.model_logs.final_mw_model'

# COMMAND ----------

model_production =  mlflow.pyfunc.load_model(
    model_uri=f"models:/{model_name}/4"
)

# COMMAND ----------

model_versions = client.search_model_versions(
    filter_string=f"name = '{model_name}'",
    
    
)

# COMMAND ----------

versions = []
for mv in model_versions:
    versions.append(int(mv.version))

# COMMAND ----------

versions.sort(reverse=True)
latest_version = str(versions[0])


# COMMAND ----------


model_uri_latest = f'models:/ispl_databricks.model_logs.final_mw_model/{latest_version}'
model_latest = mlflow.pyfunc.load_model(model_uri_latest)


# COMMAND ----------

model_info = mlflow.models.get_model_info(model_uri_latest)

# COMMAND ----------


feature_names = model_info.signature.inputs.input_names()

# COMMAND ----------

test_data_latest = test_data_latest[feature_names]

# COMMAND ----------

# predictions = []
# for i in range(100):
#     test_i = test_data.iloc[[i]]
#     pred = model_latest.predict(test_i)
#     pred = pred.tolist()
#     test_i_dict = test_i.iloc[0].to_dict()
#     test_i_dict['prediction'] = pred
#     test_i_dict['model_name'] = model_uri_latest.split('/')[1]
#     test_i_dict['model_version'] = latest_version
#     predictions.append(test_i_dict)

# for i in range(100):
#     test_i = test_data.iloc[[i]]
#     pred = model_x.predict(test_i)
#     pred = pred.tolist()
#     test_i_dict = test_i.iloc[0].to_dict()
#     test_i_dict['prediction'] = pred
#     test_i_dict['model_name'] = model_uri_x.split('/')[1]
#     test_i_dict['model_version'] = version_x
#     predictions.append(test_i_dict)

# COMMAND ----------

from sklearn.metrics import accuracy_score

# COMMAND ----------

latest_model_prediction = model_latest.predict(test_data_latest)
production_model_prediction = model_production.predict(test_production_data)

# COMMAND ----------

len(latest_model_prediction)

# COMMAND ----------

latest_result = []
for x in latest_model_prediction:
    if x[0]>0.5:
        latest_result.append(1)
    else:
        latest_result.append(0)
x_result = []
for x in production_model_prediction:
    if x[0]>0.5:
        x_result.append(1)
    else:
        x_result.append(0)

# COMMAND ----------

latest_model_accuracy = accuracy_score(test_target_latest['target_30_dpd'].values,np.array(latest_result))
model_production_accuracy = accuracy_score(test_production_target['target_30_dpd'].values,np.array(x_result))
latest_model_auc = roc_auc_score(test_target_latest['target_30_dpd'].values,np.array(x_result))
model_production_auc = roc_auc_score(test_production_target['target_30_dpd'].values,np.array(x_result))
latest_model_precision = precision_score(test_target_latest['target_30_dpd'].values,np.array(x_result))
model_production_precision = precision_score(test_production_target['target_30_dpd'].values,np.array(x_result))
latest_model_recall = recall_score(test_target_latest['target_30_dpd'].values,np.array(x_result))
model_production_recall = recall_score(test_production_target['target_30_dpd'].values,np.array(x_result))

# COMMAND ----------

print('xxx',latest_model_accuracy)
print('yyy',model_production_accuracy)

# COMMAND ----------

if latest_model_accuracy > model_production_accuracy:
    requests.post(
        "https://hooks.slack.com/services/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",
        json={
            "text": (
                "🚀 *Model Approval Required*\n"
                f"Model: {model_name}\n"
                f"New Accuracy: {latest_model_accuracy:.4f}\n"
                f"Champion Accuracy: {model_production_accuracy:.4f}\n\n"
                "Please review and approve promotion in Databricks."
            )
        }
    )

# COMMAND ----------

