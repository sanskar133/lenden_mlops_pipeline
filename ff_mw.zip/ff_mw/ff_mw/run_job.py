# Databricks notebook source
from databricks.sdk.service.jobs import JobSettings
from databricks.sdk import WorkspaceClient

# COMMAND ----------

w = WorkspaceClient()

# COMMAND ----------

run = w.jobs.run_now(
    job_id=1108510911086509
)

# COMMAND ----------

# run = w.jobs.run_now(
#     job_id=238563918452880
# )