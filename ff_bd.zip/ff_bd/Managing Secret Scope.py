# Databricks notebook source
token = "dapibb5c2dba1a90037699e7f643910677a9"

# COMMAND ----------

def create_scope(scope_name, DATABRICKS_INSTANCE="https://dbc-93aaa555-94f1.cloud.databricks.com/", TOKEN=token):
    import requests
    DATABRICKS_INSTANCE = DATABRICKS_INSTANCE
    TOKEN = TOKEN

    # Create secret scope API
    url = f"{DATABRICKS_INSTANCE}/api/2.0/secrets/scopes/create"
    headers = {
        "Authorization": f"Bearer {TOKEN}",
        "Content-Type": "application/json"
    }

    payload = {
        "scope": scope_name,
        "initial_manage_principal": "users"  # Specify who can manage secrets
    }

    response = requests.post(url, headers=headers, json=payload)
    if response.status_code == 200:
        print(f"Scope '{scope_name}' created successfully.")
    else:
        print(f"Failed to create scope: {response.status_code}, {response.json()}")

# COMMAND ----------

create_scope(scope_name="lms")
create_scope(scope_name="sc")
create_scope(scope_name="sc_los")
create_scope(scope_name="los")
create_scope(scope_name="sc_old")

# COMMAND ----------

def create_secret(scope_name, secrets_dict, DATABRICKS_INSTANCE="https://dbc-93aaa555-94f1.cloud.databricks.com/", TOKEN=token):
    import requests

    DATABRICKS_INSTANCE = DATABRICKS_INSTANCE
    TOKEN = TOKEN
    SCOPE = scope_name

    secrets_dict = secrets_dict

    # API URL
    url = f"{DATABRICKS_INSTANCE}/api/2.0/secrets/put"

    # Headers
    headers = {
        "Authorization": f"Bearer {TOKEN}",
        "Content-Type": "application/json"
    }

    # Loop through secrets dictionary
    for key, value in secrets_dict.items():
        payload = {
            "scope": SCOPE,
            "key": key,
            "string_value": value
        }
        
        response = requests.post(url, headers=headers, json=payload)
        
        if response.status_code == 200:
            print(f"Secret '{key}' added successfully.")
        else:
            print(f"Failed to add secret '{key}': {response.status_code}, {response.json()}")


# COMMAND ----------

secrets_dict = {
  "jdbc_url": "jdbc:postgresql://ldc-lms-prod.cluster-ro-c60xechvrdpu.ap-south-1.rds.amazonaws.com:5432/prodldclms",
  "host": "ldc-lms-prod.cluster-ro-c60xechvrdpu.ap-south-1.rds.amazonaws.com",
  "username": "read_usrprodldclms",
  "password": "LeeRmG8d4Csc!jLdzEeRbvzK",
  "database": "prodldclms"
}
create_secret("lms", secrets_dict)

# COMMAND ----------

secrets_dict = {
  "jdbc_url": "jdbc:postgresql://scorecard.c60xechvrdpu.ap-south-1.rds.amazonaws.com:5432/scorecard",
  "host": "scorecard.c60xechvrdpu.ap-south-1.rds.amazonaws.com",
  "username": "read_score",
  "password": "Re!c!Shiav4prIADq",
  "database": "scorecard"
}
create_secret("sc", secrets_dict)

# COMMAND ----------

secrets_dict = {
  "jdbc_url": "jdbc:postgresql://scorecard.c60xechvrdpu.ap-south-1.rds.amazonaws.com:5432/scorecard_los",
  "host": "scorecard.c60xechvrdpu.ap-south-1.rds.amazonaws.com",
  "username": "postgres",
  "password": "E3#=Gnx%8*Hn",
  "database": "scorecard_los"
}
create_secret("sc_los", secrets_dict)

# COMMAND ----------

secrets_dict = {
  "jdbc_url": "jdbc:postgresql://ldc-prod-im-los.cluster-ro-c60xechvrdpu.ap-south-1.rds.amazonaws.com:5432/ldcdb_imlos",
  "host": "ldc-prod-im-los.cluster-ro-c60xechvrdpu.ap-south-1.rds.amazonaws.com",
  "username": "read_usrimlos",
  "password": "psA9Yq$bjT4?jYBe",
  "database": "ldcdb_imlos"
}
create_secret("los", secrets_dict)

# COMMAND ----------

secrets_dict = {
  "jdbc_url": "jdbc:postgresql://scorecard.c60xechvrdpu.ap-south-1.rds.amazonaws.com:5432/scorecard",
  "host": "scorecard.c60xechvrdpu.ap-south-1.rds.amazonaws.com",
  "username": "postgres",
  "password": "E3#=Gnx%8*Hn",
  "database": "scorecard"
}
create_secret("sc_old", secrets_dict)

# COMMAND ----------



# COMMAND ----------

