# Databricks notebook source
# MAGIC %pip install databricks-feature_engineering

# COMMAND ----------

# MAGIC  %restart_python

# COMMAND ----------


from databricks.feature_engineering import FeatureEngineeringClient

# COMMAND ----------

fe = FeatureEngineeringClient()
fe.create_online_store(
    name="my-online-storebd",
    capacity="CU_1"  # or CU_2, CU_4, CU_8
)

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE ispl_databricks.model_logs.bd_final_feature_stores
# MAGIC SET TBLPROPERTIES (delta.enableChangeDataFeed = true)