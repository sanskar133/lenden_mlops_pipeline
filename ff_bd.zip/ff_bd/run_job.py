# Databricks notebook source
from databricks.sdk.service.jobs import JobSettings
from databricks.sdk import WorkspaceClient

# COMMAND ----------

w = WorkspaceClient()


# COMMAND ----------

run = w.jobs.run_now(
    job_id=953703325246071
)