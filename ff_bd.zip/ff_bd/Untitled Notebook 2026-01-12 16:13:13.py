# Databricks notebook source
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders

# COMMAND ----------


def send_email(sender_email, receiver_email, password, subject, body, attachment_path=None):
    # Create message
    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = receiver_email
    message['Subject'] = subject
    
    # Add body
    message.attach(MIMEText(body, 'plain'))
    
    # Add attachment (optional)
    if attachment_path:
        with open(attachment_path, 'rb') as attachment:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename= {attachment_path.split("/")[-1]}')
            message.attach(part)

# COMMAND ----------

send_email(
    sender_email="sanskar.shrivastava@aidetic.in",
    receiver_email="manu.sanskar@gmail.com",
    password=dbutils.secrets.get(scope="email-secrets", key="email-password"),
    subject="Databricks Job Status",
    body="Your ETL pipeline completed successfully!"
)

# COMMAND ----------

import requests

def send_email_sendgrid(api_key, sender_email, receiver_email, subject, body):
    url = "https://api.sendgrid.com/v3/mail/send"
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    data = {
        "personalizations": [{
            "to": [{"email": receiver_email}],
            "subject": subject
        }],
        "from": {"email": sender_email},
        "content": [{
            "type": "text/plain",
            "value": body
        }]
    }
    
    response = requests.post(url, headers=headers, json=data)
    
    if response.status_code == 202:
        print("Email sent successfully!")
    else:
        print(f"Failed to send email: {response.text}")

# Usage
api_key = dbutils.secrets.get(scope="email-secrets", key="sendgrid-api-key")
send_email_sendgrid(
    api_key=api_key,
    sender_email="noreply@yourcompany.com",
    receiver_email="recipient@example.com",
    subject="Pipeline Status",
    body="Data processing completed successfully!"
)