# Databricks notebook source
pip install lightgbm

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

from mlflow.tracking import MlflowClient
import mlflow

# COMMAND ----------

client = MlflowClient()

# COMMAND ----------

model_name = 'ispl_databricks.model_logs.ffbd_lgbm_all_columns_endpoint'

# COMMAND ----------


versions = client.search_model_versions(f"name='{model_name}'")


# COMMAND ----------


latest_version = max(int(v.version) for v in versions)


# COMMAND ----------

latest_version

# COMMAND ----------

model_uri_500 = f"models:/{model_name}/{latest_version}"

# COMMAND ----------

model_500 = mlflow.pyfunc.load_model(model_uri_500)

# COMMAND ----------


mv = client.get_model_version(model_name, latest_version)

# COMMAND ----------

run_id = mv.run_id

# COMMAND ----------

accuracy = client.get_run(run_id).data.metrics["test_accuracy"]

# COMMAND ----------

accuracy

# COMMAND ----------

model_50_name = 'ispl_databricks.model_logs.final_bd_model'

# COMMAND ----------

versions50 = client.search_model_versions(f"name='{model_50_name}'")


# COMMAND ----------

latest_version50 = max(int(v.version) for v in versions50)

# COMMAND ----------

print(latest_version50)

# COMMAND ----------

model_uri_50  = f"models:/{model_50_name}/{latest_version50}"
model_50 = mlflow.pyfunc.load_model(model_uri_50)

# COMMAND ----------

mv_50 = client.get_model_version(model_50_name, latest_version)

# COMMAND ----------

run_id = mv.run_id

# COMMAND ----------

accuracy50 = client.get_run(run_id).data.metrics["test_accuracy"]

# COMMAND ----------

accuracy50

# COMMAND ----------

print(accuracy50)
print(accuracy)