# Databricks notebook source
!pip install lightgbm

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import os
import json
import pandas as pd
import pickle
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
import joblib
from datetime import datetime, date
import mlflow
import mlflow.lightgbm
from sklearn.metrics import classification_report,roc_auc_score,f1_score
from mlflow.models.signature import infer_signature
from sklearn.preprocessing import LabelEncoder
import json
import requests
import matplotlib.pyplot as plt
import seaborn as sns
from mlflow.tracking import MlflowClient
from sklearn.metrics import accuracy_score


# COMMAND ----------

model_name_500 = 'ispl_databricks.model_logs.ffbd_lgbm_all_columns_endpoint'
model_name_50 = 'ispl_databricks.model_logs.final_bd_model'

# COMMAND ----------

client =MlflowClient()

# COMMAND ----------

# Fetch all registered model versions for the 500-feature model
version500 = client.search_model_versions(f"name='{model_name_500}'")

# Fetch all registered model versions for the 50-feature model
version50 = client.search_model_versions(f"name='{model_name_50}'")

# COMMAND ----------

# fetching latest version for both models
latest_version500 = str(
    sorted(
        [int(versions.version) for versions in version500],
        reverse=True
    )[0]
)
latest_version50 = str(
    sorted(
        [int(versions.version) for versions in version50],
        reverse=True
    )[0]
)

# COMMAND ----------

model_uri_500 = f"models:/{model_name_500}/{latest_version500}"
model_uri_50 = f"models:/{model_name_50}/{latest_version50}"

# COMMAND ----------

# Retrieve the latest model version details from MLflow Model Registry
# for the full-feature (500) model
mv500 = client.get_model_version(name=model_name_500, version=latest_version500)
# Retrieve the latest model version details from MLflow Model Registry
# for the reduced-feature (50) model
mv50 = client.get_model_version(name=model_name_50, version=latest_version50)

# COMMAND ----------

# Extract run ID associated with the 500-feature model version
mv500run_id = mv500.run_id
# Get the MLflow run ID that produced the latest 50-feature model version
mv50run_id = mv50.run_id

# COMMAND ----------

#get details of mv500run_id,mv50run_id
info500 = client.get_run(mv500run_id)
info50 = client.get_run(mv50run_id)

# COMMAND ----------

accuracy500 = info500.data.metrics.get('test_accuracy')

# COMMAND ----------

accuracy50 = info50.data.metrics.get('test_accuracy')

# COMMAND ----------

print(accuracy500)
print(accuracy50)