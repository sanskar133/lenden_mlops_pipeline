# Databricks notebook source

from mlflow.tracking import MlflowClient
client = MlflowClient()
versions = client.search_model_versions("name = 'ispl_databricks.model_logs.final_bd_model'")

latest_version = sorted(versions, key=lambda v: int(v.version))[-1].version

# COMMAND ----------

latest_version

# COMMAND ----------

from mlflow.tracking import MlflowClient

client = MlflowClient()

# COMMAND ----------



# COMMAND ----------


challenger = client.get_model_version_by_alias(
    name="ispl_databricks.model_logs.final_bd_model",
    alias="Challenger"
)



# COMMAND ----------

challenger_run_id = challenger.run_id

# COMMAND ----------

run = client.get_run(challenger_run_id )
challenger_accuracy = run.data.metrics.get("test_accuracy")


# COMMAND ----------

latest = client.get_model_version(
    name="ispl_databricks.model_logs.final_bd_model",
    version=latest_version
)


# COMMAND ----------

run = client.get_run(latest.run_id)

# COMMAND ----------

latest_accuracy = run.data.metrics.get("test_accuracy")

# COMMAND ----------

if latest_accuracy >= challenger_accuracy:
    client.set_registered_model_alias(
    name="ispl_databricks.model_logs.final_bd_model",
    alias="Challenger",
    version=latest_version
)
    

# COMMAND ----------

