# Databricks notebook source
import json 
import requests

# COMMAND ----------

with open(
    "/Workspace/Shared/ff_bd/model_approval.json",
    "r"
) as f:
    data = json.load(f)

# COMMAND ----------

print(data)

# COMMAND ----------

model_name = data['model_name']
latest_model_accuracy = data['new_accuracy']
model_production_accuracy = data['new_auc']


# COMMAND ----------


    requests.post(
        "https://hooks.slack.com/services/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",
        json={
            "text": (
                "🚀 *Model Approval Required*\n"
                f"Model: {model_name}\n"
                f"New Accuracy: {latest_model_accuracy:.4f}\n"
                f"Champion Accuracy: {model_production_accuracy:.4f}\n\n"
                "Please review and approve promotion in Databricks."
            )
        }
    )
    run = w.jobs.run_now(
    job_id=992726689878081
)
