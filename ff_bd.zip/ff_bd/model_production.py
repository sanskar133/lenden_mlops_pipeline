# Databricks notebook source
import mlflow

# COMMAND ----------

pip install lightgbm

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------


import mlflow
import mlflow.lightgbm
import pyspark.sql.functions as F

# COMMAND ----------

from mlflow.tracking import MlflowClient

client = MlflowClient()

# COMMAND ----------


model_name = "ispl_databricks.model_logs.final_bd_model"

challenger_version = client.get_model_version_by_alias(
    name=model_name,
    alias="Challenger"
).version

print("Challenger model version:", challenger_version)

# COMMAND ----------

versions = client.search_model_versions(f"name='{model_name}'")

latest_version = max(int(v.version) for v in versions)

# COMMAND ----------

model_info = mlflow.models.get_model_info(f"models:/{model_name}/{latest_version}")

# COMMAND ----------


feature_names = model_info.signature.inputs.input_names()

# COMMAND ----------

latest_version

# COMMAND ----------

model = mlflow.pyfunc.load_model(f"models:/{model_name}/{latest_version}")

# COMMAND ----------

features = model.metadata.get_input_schema().inputs

# COMMAND ----------



# COMMAND ----------

spark_df = spark.table('ispl_databricks.model_logs.bd_final_feature_stores')

# COMMAND ----------

spark_df = spark_df.select(feature_names)

# COMMAND ----------

table_name = f"ispl_databricks.model_logs.bd_champion_{latest_version}"

# COMMAND ----------

spark_df.write \
    .format("delta") \
    .mode("append") \
    .option("overwriteSchema", "true") \
    .saveAsTable(table_name)

# COMMAND ----------

client.set_registered_model_alias(
    name=model_name,
    alias="Champion",
    version=challenger_version
)