# Databricks notebook source
!pip install lightgbm

# COMMAND ----------

# MAGIC %pip install databricks-feature_engineering

# COMMAND ----------

# MAGIC  %restart_python

# COMMAND ----------

import pandas as pd
import lightgbm as lgb
import pickle
import joblib
import mlflow
import mlflow.lightgbm
from databricks.feature_engineering import FeatureEngineeringClient
from databricks.feature_engineering import FeatureLookup
from sklearn.metrics import accuracy_score
import numpy as np
import requests
from sklearn.metrics import (
    roc_auc_score,
    precision_score,
    recall_score
)
from databricks.sdk.service.jobs import JobSettings
from databricks.sdk import WorkspaceClient

# Define job settings with approval gate


# COMMAND ----------

dbutils.widgets.text("training_csv", "")

# COMMAND ----------

input_path = dbutils.widgets.get("training_csv")

# COMMAND ----------

print(input_path)

# COMMAND ----------


df=pd.read_csv(input_path)

# COMMAND ----------

import mlflow

# COMMAND ----------

df.head()

# COMMAND ----------

df_label = spark.createDataFrame(df[['loan_id','target']])

# COMMAND ----------

fe = FeatureEngineeringClient()

# COMMAND ----------

spark_df_production = spark.table('ispl_databricks.model_logs.bd_final_inference_data')

# COMMAND ----------

df_production = spark_df_production.join(df_label, on='loan_id', how='inner')
df_production = df_production.toPandas()

# COMMAND ----------

test_production_data = df_production.drop(['loan_id','target'],axis=1)
test_production_target = df_production[['loan_id','target']]

# COMMAND ----------

fe = FeatureEngineeringClient()

# COMMAND ----------

training_set = fe.create_training_set(
    df=df_label,
    feature_lookups=[
        FeatureLookup(
            table_name="ispl_databricks.model_logs.bd_final_feature_stores",
            lookup_key="loan_id"
        )
    ],
    label="target",
   
)


# COMMAND ----------

train_df = training_set.load_df()

# COMMAND ----------

train_df = train_df.toPandas()

# COMMAND ----------

test_target = train_df[['loan_id','target']]

# COMMAND ----------

test_data = train_df.drop(['loan_id','target'], axis=1)

# COMMAND ----------

train_df.shape

# COMMAND ----------

from mlflow.tracking import MlflowClient

# COMMAND ----------


client = MlflowClient()

# COMMAND ----------

model_name = 'ispl_databricks.model_logs.final_bd_model'

# COMMAND ----------


model_versions = client.search_model_versions(
    filter_string=f"name = '{model_name}'",
    
    
)

# COMMAND ----------

versions = []
for mv in model_versions:
    versions.append(int(mv.version))

# COMMAND ----------

versions

# COMMAND ----------

versions.sort(reverse=True)

# COMMAND ----------

production_model = mlflow.pyfunc.load_model(
    model_uri=f"models:/{model_name}@champion"
)

# COMMAND ----------

for mv in model_versions:
    print(
        f"Model: {mv.name}",
        f"Version: {mv.version}",
        f"Stage: {mv.current_stage}",
        f"Created at: {mv.creation_timestamp}",
        sep=" | "
    )

# COMMAND ----------

latest_version = str(versions[0])

# COMMAND ----------

latest_version

# COMMAND ----------


model_uri_latest = f'models:/ispl_databricks.model_logs.final_bd_model/{latest_version}'
model_latest = mlflow.pyfunc.load_model(model_uri_latest)

# COMMAND ----------

# predictions = []
# for i in range(len(test_data)):
#     test_i = test_data.iloc[[i]]
#     pred = model_latest.predict(test_i)
#     pred = pred.tolist()
#     test_i_dict = test_i.iloc[0].to_dict()
#     test_i_dict['prediction'] = pred
#     test_i_dict['model_name'] = model_uri_latest.split('/')[1]
#     test_i_dict['model_version'] = latest_version
#     predictions.append(test_i_dict)

# COMMAND ----------


# for i in range(100):
#     test_i = test_data.iloc[[i]]
#     pred = model_x.predict(test_i)
#     pred = pred.tolist()
#     test_i_dict = test_i.iloc[0].to_dict()
#     test_i_dict['prediction'] = pred
#     test_i_dict['model_name'] = model_uri_x.split('/')[1]
#     test_i_dict['model_version'] = version_x
#     predictions.append(test_i_dict)

# COMMAND ----------

# final_table = spark.createDataFrame(predictions)
# display(final_table)

# COMMAND ----------

# final_table.write.format("delta").mode("overwrite").saveAsTable("ispl_databricks.model_logs.bd_evaluation")


# COMMAND ----------

# %sql
# select * from ispl_databricks.model_logs.bd_evaluation

# COMMAND ----------

model_info = mlflow.models.get_model_info(model_uri_latest)

# COMMAND ----------


feature_names = model_info.signature.inputs.input_names()

# COMMAND ----------

len(feature_names)

# COMMAND ----------



# COMMAND ----------

latest_prediction = model_latest.predict(test_data[feature_names])
production_prediction = production_model.predict(test_production_data)

# COMMAND ----------

latest_prediction 

# COMMAND ----------

latest_result = []
for i in latest_prediction:
    if i[0]>0.5:
        latest_result.append(1)
    else:
        latest_result.append(0)
production_result = []
for i in production_prediction:
    if i[0]>0.5:
        production_result.append(1)
    else:
        production_result.append(0)

# COMMAND ----------

latest_model_accuracy = accuracy_score(test_target['target'].values,np.array(latest_result))
model_production_accuracy = accuracy_score(test_production_target['target'].values,np.array(production_result))

latest_model_auc = roc_auc_score(test_target['target'].values,np.array(latest_result))
model_production_auc = roc_auc_score(test_production_target['target'].values,np.array(production_result))
latest_model_precision = precision_score(test_target['target'].values,np.array(latest_result))
model_x_precision = precision_score(test_production_target['target'].values,np.array(production_result))
latest_model_recall = recall_score(test_target['target'].values,np.array(latest_result))
model_x_recall = recall_score(test_production_target['target'].values,np.array(production_result))

# COMMAND ----------

print("latest accuracy",latest_model_accuracy)
print("model_production_accuracy",model_production_accuracy)


# COMMAND ----------

import json

# COMMAND ----------



# COMMAND ----------

json_dict = {
    "model_name": model_name,
    'new_accuracy': latest_model_accuracy,
    'new_auc': latest_model_auc,
    'latest_version':latest_version
    }

# COMMAND ----------

with open("/Workspace/Shared/ff_bd/model_approval.json", "w") as f:
    json.dump(json_dict, f)


# COMMAND ----------

if latest_model_accuracy > model_production_accuracy:
    notification = 'True'
else:
    notification = 'False'

# COMMAND ----------

dbutils.jobs.taskValues.set("trigger", notification)