# Databricks notebook source
import requests

# COMMAND ----------

import pandas as pd

# COMMAND ----------

model_uri = "https://dbc-93aaa555-94f1.cloud.databricks.com/serving-endpoints/ff_bd/invocations"

# COMMAND ----------

token = dbutils.notebook.entry_point.getDbutils().notebook().getContext().apiToken().get()

# COMMAND ----------

print(token)

# COMMAND ----------

headers = {
    "Authorization": f"Bearer {token}",
    "Content-Type": "application/json"
}

# COMMAND ----------

df = spark.table("ispl_databricks.model_logs.bd_final_inference_data")

# COMMAND ----------

df = df.drop('loan_id')

# COMMAND ----------

df = df.toPandas()

# COMMAND ----------

df.dtypes

# COMMAND ----------

payload = {
  "dataframe_records": [
    df.iloc[50].to_dict(),

  ]
}


# COMMAND ----------

response = requests.post(model_uri, headers=headers, json=payload)

# COMMAND ----------

print(response.json())